function toggleArrowUp() {
    const arrow = document.querySelector('.fa-chevron-up');
    arrow.classList.remove('rotate-down'); // Remova a classe de rotação para baixo
    arrow.classList.add('rotate-up'); // Adicione a classe de rotação para cima
  }
  
  function toggleArrowDown() {
    const arrow = document.querySelector('.fa-chevron-up');
    arrow.classList.remove('rotate-up'); // Remova a classe de rotação para cima
    arrow.classList.add('rotate-down'); // Adicione a classe de rotação para baixo
  }
  

function menuFunction() {
    var i = document.getElementById("navMenu");

    if (i.className === "nav-menu") {
        i.className += " responsive";
    } else {
        i.className = "nav-menu";
    }
}

var a = document.getElementById("loginBtn");
var b = document.getElementById("registerBtn");
var x = document.getElementById("login");
var y = document.getElementById("register");

function login() {
    toggleArrowUp(); // Adiciona a classe para girar a seta para cima
    x.style.left = "4px";
    y.style.right = "-520px";
    a.className += " white-btn";
    b.className = "btn";
    x.style.opacity = 1;
    y.style.opacity = 0;
    x.classList.remove("form-inactive");
}

function cadastro() {
    toggleArrowDown(); // Adiciona a classe para girar a seta para baixo
    x.style.left = "-510px";
    y.style.right = "5px";
    a.className = "btn";
    b.className += " white-btn";
    x.style.opacity = 0;
    y.style.opacity = 1;
    x.classList.add("form-inactive");

}
function updateTurmaOptions() {
    var cursoSelect = document.getElementById("curso");
    var turmaSelect = document.getElementById("turma");
    var selectedCursoId = cursoSelect.value; // Obtém o valor do curso selecionado (ID do curso)

    // Mapeia o valor do curso selecionado para os valores do banco de dados
    var cursoTurmaMap = {
        // Mapeie os valores do curso selecionado para os valores do banco de dados
        // Exemplo: "1" corresponde a "edificacoes" no banco de dados
        "1": ["ED-11", "ED-12", "ED-21", "ED-22", "ED-31", "ED-32", "ED-41"],
        "2": ["EI-11", "EI-12", "EI-21", "EI-22", "EI-31", "EI-32", "EI-41"],
        "3": ["EMA-11", "EMA-12", "EMA-21", "EMA-22", "EMA-31", "EMA-32", "EMA-41"]
    };

    turmaSelect.innerHTML = ""; // Limpa as opções anteriores

    if (cursoTurmaMap.hasOwnProperty(selectedCursoId)) {
        var turmas = cursoTurmaMap[selectedCursoId];

        for (var i = 0; i < turmas.length; i++) {
            var option = document.createElement("option");
            option.value = turmas[i];
            option.text = turmas[i];
            turmaSelect.appendChild(option);
        }
    }
}

$(document).ready(function() {
    $('#register input[name="telefone"]').mask('(00) 00000-0000');
});

$(document).ready(function() {
    $('#register input[name="cep"]').mask('00000-000');
});
