<?php
session_start();

// Função para exibir uma mensagem em um elemento de mensagem
function mostrarMensagem($idElementoMensagem, $mensagem, $cor)
{
    // JavaScript para exibir o elemento de mensagem
    echo "<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Obter o elemento de mensagem pelo seu ID
        var elementoMensagem = document.getElementById('$idElementoMensagem');
        // Definir o conteúdo e estilos da mensagem
        elementoMensagem.innerHTML = '$mensagem';
        elementoMensagem.style.color = '$cor';
        elementoMensagem.style.fontWeight = 'bold';
        elementoMensagem.style.fontSize = '14px';
        elementoMensagem.style.padding = '12px';
        elementoMensagem.style.borderRadius = '8px';
        elementoMensagem.style.marginTop = '10px';
        elementoMensagem.style.backgroundColor = '#f9f9f9';
        elementoMensagem.style.border = '1px solid $cor';
        elementoMensagem.style.boxShadow = '0px 2px 4px rgba(0, 0, 0, 0.1)';
        // Exibir o elemento de mensagem
        elementoMensagem.style.display = 'block';
    });
    </script>";
}

// Verificar se há uma mensagem de sucesso na sessão
if (isset($_SESSION['cadastro_sucesso'])) {
    // Exibir a mensagem de sucesso
    mostrarMensagem('cadastrocerto', 'Cadastro realizado com sucesso!', 'green');
    // Remover a variável de sessão
    unset($_SESSION['cadastro_sucesso']);
}
// Verificar se há uma mensagem de erro para o cadastro na sessão
elseif (isset($_SESSION['cadastro_erro'])) {
    // Construir a mensagem de erro
    $mensagemErro = "Erro de cadastro: " . $_SESSION['cadastro_erro'];
    // Exibir a mensagem de erro
    mostrarMensagem('registerErrorMessage', $mensagemErro, 'red');
    // Remover a variável de sessão
    unset($_SESSION['cadastro_erro']);
}

// Verificar se há uma mensagem de erro para o login na sessão
if (isset($_SESSION['login_erro'])) {
    // Construir a mensagem de erro
    $mensagemErro = "Erro de login: " . $_SESSION['login_erro'];
    // Exibir a mensagem de erro
    mostrarMensagem('loginErrorMessage', $mensagemErro, 'red');
    // Remover a variável de sessão
    unset($_SESSION['login_erro']);
}
if (isset($_GET['cep'])) {
    $cep = $_GET['cep'];
    $cep = preg_replace('/[^0-9]/', '', $cep);

    if (strlen($cep) == 8) {
        $url = "https://viacep.com.br/ws/{$cep}/json/";
        $result = file_get_contents($url);
        echo $result;
    }
}
// Verificar se a página atual é a página de cadastro
$paginaCadastro = false;
if (basename($_SERVER['PHP_SELF']) == 'registro.php') {
    $paginaCadastro = true;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
    <title>Ludiflex | Login & Registration</title>
</head>

<body>
    <div class="wrapper">
        <nav class="nav">
            <div class="nav-logo">
                <p>LOGO .</p>
            </div>
            <div class="nav-menu" id="navMenu">
                <ul>
                    <li><a href="#" class="link active">Inicio</a></li>
                    <li><a href="novidades_em_breve.html" class="link">Sobre</a></li>
                    <li><a href="novidades_em_breve.html" class="link">Não definido</a></li>
                    <li><a href="suporte.html" class="link">Fale Conosco</a></li>
                </ul>
            </div>
            <div class="nav-button">
                <button class="btn white-btn" id="loginBtn" onclick="login()">Sign In</button>
                <button class="btn" id="registerBtn" onclick="register()">Sign Up</button>
            </div>
            <div class="nav-menu-btn">
                <i class="bx bx-menu" onclick="myMenuFunction()"></i>
            </div>
        </nav>

        <!----------------------------- Form box ----------------------------------->
        <div class="form-box">

            <!------------------- login form -------------------------->

            <div class="login-container" id="login">
                <div class="top">
                    <span>Não tem uma conta? <a href="#" onclick="register()">Cadastre-se</a></span>
                    <header>Login</header>
                    <div id="cadastrocerto-login" class="certo-message mensagem-container" style="display: none;"></div>
                    <div id="registerErrorMessage-login" class="error-message mensagem-container" style="display: none;"></div>
                    <div id="loginErrorMessage-login" class="error-message mensagem-container" style="display: none;"></div>
                    <br>
                </div>
                <form action="login.php" method="POST">
                <div class="input-box">
                    <input type="text" class="input-field" placeholder="Matrícula" name="matricula" required>
                    <i class="bx bx-user"></i>
                </div>
                <div class="input-box">
                    <input type="password" class="input-field" placeholder="Senha" name="senha" required>
                    <i class="bx bx-lock-alt"></i>
                </div>
                <div class="input-box">
                    <input type="submit" class="submit" value="Login" name="login">
                </div>
                <div class="two-col">
                    <div class="one">
                        <input type="checkbox" id="login-check">
                        <label for="login-check"> Relembre-me</label>
                    </div>

                    <div class="two">
                        <label><a href="#">Esqueceu a senha?</a></label>
                    </div>
                </div>
                </form>
            </div>

            <!------------------- registration form -------------------------->
            <div class="register-container elemento-com-barra-de-rolagem" id="register">
                <div class="top">
                    <span>Já tem uma conta? <a href="#" onclick="login()">Login</a></span>
                    <header>Cadastre-se</header>
                </div>
                <div id="cadastrocerto-cadastro" class="certo-message mensagem-container" style="display: none;"></div>
                    <div id="registerErrorMessage-cadastro" class="error-message mensagem-container" style="display: none;"></div>
                    <div id="loginErrorMessage-cadastro" class="error-message mensagem-container" style="display: none;"></div>
                <form action="registro.php" method="POST">
                <div class="two-forms">
                <div class="two-forms">
                        <div class="input-box">
                            <input type="text" class="input-field" placeholder="Nome" name="nome" required>
                            <i class="bx bx-user"></i>
                        </div>
                        <div class="input-box">
                            <input type="text" class="input-field" placeholder="Sobrenome" name="sobrenome" required>
                            <i class="bx bx-user"></i>
                        </div>
                    </div>
                    <div class="input-box">
                        <input type="text" class="input-field" placeholder="Matrícula" name="matricula" pattern="[0-9]{12}" title="Digite uma matrícula com 12 dígitos" required>
                        <i class="bx bx-envelope"></i>
                    </div>
                    <div class="input-box">
                        <input type="text" class="input-field" placeholder="Telefone" name="telefone" data-mask="(00) 00000-0000" required>
                        <i class="bx bx-phone"></i>
                    </div>
                    <div class="input-box">
                        <input id="cep" type="text" class="input-field" placeholder="CEP" name="cep" id="cep" data-mask="00000-000">
                        <i class="bx bx-location-plus"></i>
                    </div>
                    <div class="input-box">
                        <input type="text" class="input-field" placeholder="Rua" name="rua" id="rua" readonly required>
                        <i class="bx bx-home-alt"></i>
                    </div>
                    <div class="input-box">
                        <input type="text" class="input-field" placeholder="Bairro" name="bairro" id="bairro" readonly required>
                        <i class="bx bx-home"></i>
                    </div>
                    <div class="input-box">
                        <input type="text" class="input-field" placeholder="Cidade" name="cidade" id="cidade" readonly required>
                        <i class="bx bx-building-house"></i>
                    </div>
                    <div class="input-box">
                        <input type="text" class="input-field" placeholder="Estado" name="estado" id="estado" readonly required>
                        <i class="bx bx-flag"></i>
                    </div>
                    <div class="input-box">
                        <input type="text" class="input-field" placeholder="Número da Casa" name="numerocasa" id="numerocasa" required>
                        <i class="bx bx-home"></i> <!-- Ícone de casa -->
                    </div>
                    <div class="input-box">
                        <i class="bx bxs-school"></i>
                    </div>
                    <div class="input-box">
                        <input type="password" class="input-field" placeholder="Senha" name="senha" required>
                        <i class="bx bx-lock-alt"></i>
                    </div>
                    <div class="input-box">
                        <input type="password" class="input-field" placeholder="Confirmar Senha" name="confirmar_senha" required>
                        <i class="bx bx-lock-alt"></i>
                    </div>
                    <div class="input-box">
                        <input type="submit" class="submit" value="Cadastre-se" name="cadastrar">
                    </div>
                    <div class="two-col">
                        <div class="one">
                            <input type="checkbox" id="register-check">
                            <label for="register-check"> Relembre-me</label>
                        </div>
                        <div class="two">
                            <label><a href="#">Termos & condições</a></label>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <script>

        function myMenuFunction() {
            var i = document.getElementById("navMenu");

            if (i.className === "nav-menu") {
                i.className += " responsive";
            } else {
                i.className = "nav-menu";
            }
        }

    </script>

    <script>

        var a = document.getElementById("loginBtn");
        var b = document.getElementById("registerBtn");
        var x = document.getElementById("login");
        var y = document.getElementById("register");

        function login() {
            x.style.left = "4px";
            y.style.right = "-520px";
            a.className += " white-btn";
            b.className = "btn";
            x.style.opacity = 1;
            y.style.opacity = 0;
        }

        function register() {
            x.style.left = "-510px";
            y.style.right = "5px";
            a.className = "btn";
            b.className += " white-btn";
            x.style.opacity = 0;
            y.style.opacity = 1;
        }

    </script>

</body>

</html>