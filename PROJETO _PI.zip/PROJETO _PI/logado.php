<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

function validarCodigo($codigo) {
    // Lógica de validação do código
    // Substitua isso com sua própria lógica de validação
    return $codigo === "codigo_correto";
}

function gerarCodigo() {
    // Gera um código aleatório seguro
    return bin2hex(openssl_random_pseudo_bytes(4));
}

function enviarCodigoPorEmail($codigo, $email) {
    // Cria uma instância do PHPMailer
    $mail = new PHPMailer(true);

    try {
        // Configurações do servidor SMTP
        $mail->isSMTP();
        $mail->Host       = 'smtp.example.com';  // Substitua pelo seu servidor SMTP
        $mail->SMTPAuth   = true;
        $mail->Username   = 'seu_email@example.com';  // Substitua pelo seu e-mail
        $mail->Password   = 'sua_senha';  // Substitua pela sua senha
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

        // Configurações do e-mail
        $mail->setFrom('zeniniti@gmail.com', 'Seu Nome');  // Substitua pelo seu e-mail e nome
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = 'Código de validação para sua conta';
        $mail->Body    = "Seu código de validação é: $codigo";

        // Envia o e-mail
        $mail->send();

        echo "Código enviado por e-mail!";
    } catch (Exception $e) {
        echo "Erro ao enviar e-mail: {$mail->ErrorInfo}";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['validar'])) {
        $codigo_inserido = $_POST["codigo"];
        $codigo_valido = validarCodigo($codigo_inserido);

        if ($codigo_valido) {
            echo "Código válido. Conta validada com sucesso!";
        } else {
            echo "Código inválido. Tente novamente.";
            sleep(30);
        }
    } elseif (isset($_POST['enviarEmail'])) {
        // Gerar um novo código
        $codigo = gerarCodigo();

        // Puxar o email do usuário do banco de dados
        $usuarioMatricula = $_SESSION['matricula'];
        $conexao = new mysqli("seu_host", "seu_usuario", "sua_senha", "requerimento"); // Substitua com suas credenciais de banco de dados
        $consulta = $conexao->query("SELECT email FROM usuarios WHERE matricula = '$usuarioMatricula'");
        $dadosUsuario = $consulta->fetch_assoc();
        $emailUsuario = $dadosUsuario['email'];

        // Salvar o código na sessão
        $_SESSION['codigo_validacao'] = $codigo;

        // Enviar o código por e-mail
        enviarCodigoPorEmail($codigo, $emailUsuario);
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style2.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        /* Adicione o seguinte estilo para o contêiner dos botões */
        .button-container {
            display: flex;
            justify-content: space-between;
        }

        /* Adicione este estilo para dar algum espaçamento entre os botões */
        .button-container button {
            margin-right: 5px;
        }
    </style>
</head>

<body>
    <div class="header">
        <div class="header-left">
            <p>Bem-vindo(a) <?php echo $_SESSION['nome']; ?>!</p>
        </div>
        <div class="header-icon" onclick="toggleMenu()">
            <i class='bx bxs-user'></i>
            <div class="options-menu" id="optionsMenu">
                <a href="#">Ir para o perfil</a>
                <a href="#">Alterar cadastro</a>
                <a href="#">Configurações</a>
                <a href="logout.php">Sair</a>
            </div>
        </div>
    </div>

    <div class="box">
        <p>Faça a validação a partir do código que irá chegar no seu e-mail: <?php echo $_SESSION['matricula'], "@ifba.edu.br"; ?>.</p>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="codigo">Digite o código de validação:</label>
            <input type="text" id="codigo" name="codigo" required>
            <!-- Adicione o contêiner para os botões -->
            <div class="button-container">
                <button type="submit" name="validar">Validar Conta</button>
                <button type="submit" name="enviarEmail">Solicitar Código Novamente</button>
            </div>
        </form>
    </div>

    <script>
    function toggleMenu() {
        var menu = document.getElementById("optionsMenu");
        var icon = document.querySelector(".header-icon");

        menu.classList.toggle("active");
        icon.classList.toggle("active");

    }
</script>

</body>

</html>
