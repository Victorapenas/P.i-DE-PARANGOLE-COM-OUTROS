<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <?php
    // Verificar se o formulário foi enviado
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $emailCorreto = "usuario@example.com";
        $senhaCorreta = "senha123";

        $email = $_POST["email"];
        $senha = $_POST["senha"];

        // Verificar as credenciais
        if ($email === $emailCorreto && $senha === $senhaCorreta) {
            // Login bem-sucedido, redirecionar para a página de sucesso
            header("Location: pagina_de_sucesso.php");
            exit();
        } else {
            $mensagemErro = "Email ou senha incorretos.";
        }
    }
    ?>

    <h1>Login</h1>
    <?php if (isset($mensagemErro)) { ?>
        <p style="color: red;"><?php echo $mensagemErro; ?></p>
    <?php } ?>
    <form method="post">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>

        <label for="senha">Senha:</label>
        <input type="password" id="senha" name="senha" required><br><br>

        <button type="submit">Entrar</button>
    </form>
</body>
</html>
