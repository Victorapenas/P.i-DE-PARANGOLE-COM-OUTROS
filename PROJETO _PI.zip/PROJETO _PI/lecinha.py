import PySimpleGUI as sg
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

sg.theme('LightGrey1')

# Definindo o layout da tela inicial
layout_inicial = [
    [sg.Text('Bem-vindo ao Programa de Contabilidade', font=('Helvetica', 20), justification='center')],
    [sg.Button('Gerenciamento de Estoque', size=(25, 2), font=('Helvetica', 14))],
    [sg.Button('Análise de Vendas', size=(25, 2), font=('Helvetica', 14))],
    [sg.Button('Sair', size=(25, 2), font=('Helvetica', 14))]
]

# Definindo o layout da tela de gerenciamento de estoque
layout_gerenciamento_estoque = [
    [sg.Text('Lista de Produtos', font=('Helvetica', 20), justification='center')],
    [sg.Table(values=[], headings=['Nome', 'Quantidade', 'Data de Validade'], key='-PRODUTOS-', font=('Helvetica', 12))],
    [sg.Button('Adicionar Produto', font=('Helvetica', 12)), sg.Button('Editar Produto', font=('Helvetica', 12)), sg.Button('Voltar', font=('Helvetica', 12))]
]

# Definindo o layout da tela de adição/editação de produto
layout_adicao_edicao_produto = [
    [sg.Text('Nome do Produto:', font=('Helvetica', 14)), sg.InputText(key='-NOME-', font=('Helvetica', 14))],
    [sg.Text('Quantidade em Estoque:', font=('Helvetica', 14)), sg.InputText(key='-QUANTIDADE-', font=('Helvetica', 14))],
    [sg.Text('Data de Validade:', font=('Helvetica', 14)), sg.InputText(key='-VALIDADE-', font=('Helvetica', 14))],
    [sg.Button('Confirmar', font=('Helvetica', 12)), sg.Button('Cancelar', font=('Helvetica', 12))]
]

# Definindo o layout da tela de análise de vendas
layout_analise_vendas = [
    [sg.Text('Análise de Vendas', font=('Helvetica', 20), justification='center')],
    [sg.Canvas(key='-CANVAS-')],
    [sg.Table(values=[], headings=['Produto', 'Quantidade Vendida', 'Receita'], key='-PRODUTOS-VENDIDOS-', font=('Helvetica', 12))],
    [sg.Button('Detalhes do Produto', font=('Helvetica', 12)), sg.Button('Voltar', font=('Helvetica', 12))]
]

# Definindo o layout da tela de detalhes do produto
layout_detalhes_produto = [
    [sg.Text('Detalhes do Produto', font=('Helvetica', 20), justification='center')],
    [sg.Canvas(key='-CANVAS-')],
    [sg.Text('Lucro Gerado:', font=('Helvetica', 16))],
    [sg.Button('Voltar', font=('Helvetica', 12))]
]

# Criando as janelas com os layouts definidos
janela_inicial = sg.Window('Programa de Contabilidade', layout_inicial, finalize=True)
janela_gerenciamento_estoque = sg.Window('Gerenciamento de Estoque', layout_gerenciamento_estoque, finalize=True)
janela_adicao_edicao_produto = sg.Window('Adicionar/Editar Produto', layout_adicao_edicao_produto, finalize=True)
janela_analise_vendas = sg.Window('Análise de Vendas', layout_analise_vendas, finalize=True)
janela_detalhes_produto = sg.Window('Detalhes do Produto', layout_detalhes_produto, finalize=True)

# Loop principal para interação com as telas
while True:
    evento, valores = janela_inicial.read()

    if evento in (sg.WINDOW_CLOSED, 'Sair'):
        break
    elif evento == 'Gerenciamento de Estoque':
        janela_inicial.hide()
        janela_gerenciamento_estoque = sg.Window('Gerenciamento de Estoque', layout_gerenciamento_estoque)
        while True:
            evento_gerenciamento, valores_gerenciamento = janela_gerenciamento_estoque.read()
            if evento_gerenciamento in (sg.WINDOW_CLOSED, 'Voltar'):
                janela_gerenciamento_estoque.close()
                break
            elif evento_gerenciamento == 'Adicionar Produto':
                # Lógica para adicionar produto
                pass
            elif evento_gerenciamento == 'Editar Produto':
                # Lógica para editar produto
                pass
    elif evento == 'Análise de Vendas':
        janela_inicial.hide()
        janela_analise_vendas = sg.Window('Análise de Vendas', layout_analise_vendas)
        while True:
            evento_analise, valores_analise = janela_analise_vendas.read()
            if evento_analise in (sg.WINDOW_CLOSED, 'Voltar'):
                janela_analise_vendas.close()
                break
            elif evento_analise == 'Detalhes do Produto':
                # Lógica para detalhes do produto
                pass

# Fechar as janelas ao sair do loop
janela_inicial.close()
janela_gerenciamento_estoque.close()
janela_adicao_edicao_produto.close()
janela_analise_vendas.close()
janela_detalhes_produto.close()
