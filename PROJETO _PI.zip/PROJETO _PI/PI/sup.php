<?php

    $nome = addslashes($_POST['nome']);
    $matricula = addslashes($_POST['matricula']);
    $emai = addslashes($_POST['email']);
    $mensagem = addslashes($_POST['mensagem']);

    $to = "golpenominecraft@gmail.com";
    $assunto = "Suporte requerimento";

    $body = "Nome: ".$nome."\n"."Matrícula: ".$matricula."\n"."E-mail: ".$emai."\n"."Mensagem: ".$mensagem;

    $header = "From: tataurocha20@hotmail.com"."\n"."Reply-to: ".$emai."\n"."X=Mailer:PHP/".phpversion();

    if(mail($to,$assunto,$body,$header)){
        echo("Email enviado com sucesso!");
    }else{
        echo("Houve um erro ao enviar o email!");
    }


?>