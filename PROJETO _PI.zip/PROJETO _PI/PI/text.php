<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="esse.css">
    <title>Projeto Integrador</title>
</head>

<body>

<div class="background">
   <div class="shape"></div>
   <div class="shape"></div>
</div>

<form>
  <h3>Login</h3>

  <label for="username">Username</label>
  <input type="text" placeholder="email" id="username">

  <label for="password">Password</label>
  <input type="password" placeholder="senha" id="password">
  <a href="" class="esqueci_senha">Esqueci a senha</a>

  <button>Login</button>
  <div class="social">
    <div class="go"><i class="fab fa-google"></i> Google</div>
    <div class="fb"><i class="fab fa-facebook"></i>
Facebook</div>
</form>
 <?php

    extract($_POST);

    if (isset($botao)) {

        
    // Condicional usada para login de adm, nao precissa ser refeita ultilizando dados do BD,
    // somente ultilizando uma lista em php para salvar nome dos adms

        $adm_usuarios=array("dayvid", "pereira", "kauan", "line");
        $adm_senhas=array(1111, 2222, 3333, 4444);

        if (in_array($email, $adm_usuarios)){

            $indice = array_search($email, $adm_usuarios);

            if ($senha == $adm_senhas[$indice]){

                echo "<div style='font-size:25px; color:blue; margin-top:20px;'>Acesso Autorizado (ADM)<br> </div>";
        
            }

            if ($senha != $adm_senhas[$indice]){

                echo "<div style='font-size:25px; color:red; margin-top:20px;'>Usuario ou Senha invalido<br> </div>";
        
            }}

        else{

            
            // Dados temporarios para "verificacao"
            $email_certo="dayvid@gmail.com"; 
            $senha_certo="1234";

            //!!!criar condiçao!!! --> caso usuario e senha do BD estejam corretos
            if ($email == $email_certo & $senha == $senha_certo) {
        
                echo "<div style='font-size:25px; color:green; margin-top:20px;'>Acesso Autorizado<br> </div>";
        
            }
            //!!!criar condiçao!!! --> caso usuario ou senha do BD nao estejam corretos
            if ($email != $email_certo or $senha != $senha_certo) {
        
                echo "<div style='font-size:25px; color:red; margin-top:20px;'>Usuario ou Senha invalido<br> </div>";
        
            }}

}

?>
</body>
</html>