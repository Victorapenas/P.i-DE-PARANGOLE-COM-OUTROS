<?php
session_start();

// Função para exibir uma mensagem em um elemento de mensagem
function mostrarMensagem($idElementoMensagem, $mensagem, $cor)
{
    // JavaScript para exibir o elemento de mensagem
    echo "<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Obter o elemento de mensagem pelo seu ID
        var elementoMensagem = document.getElementById('$idElementoMensagem');
        // Definir o conteúdo e estilos da mensagem
        elementoMensagem.innerHTML = '$mensagem';
        elementoMensagem.style.color = '$cor';
        elementoMensagem.style.fontWeight = 'bold';
        elementoMensagem.style.fontSize = '14px';
        elementoMensagem.style.padding = '12px';
        elementoMensagem.style.borderRadius = '8px';
        elementoMensagem.style.marginTop = '10px';
        elementoMensagem.style.backgroundColor = '#f9f9f9';
        elementoMensagem.style.border = '1px solid $cor';
        elementoMensagem.style.boxShadow = '0px 2px 4px rgba(0, 0, 0, 0.1)';
        // Exibir o elemento de mensagem
        elementoMensagem.style.display = 'block';
    });
    </script>";
}

// Verificar se há uma mensagem de sucesso na sessão
if (isset($_SESSION['cadastro_sucesso'])) {
    // Exibir a mensagem de sucesso
    mostrarMensagem('cadastrocerto', 'Cadastro realizado com sucesso!', 'green');
    // Remover a variável de sessão
    unset($_SESSION['cadastro_sucesso']);
}
// Verificar se há uma mensagem de erro para o cadastro na sessão
elseif (isset($_SESSION['cadastro_erro'])) {
    // Construir a mensagem de erro
    $mensagemErro = "Erro de cadastro: " . $_SESSION['cadastro_erro'];
    // Exibir a mensagem de erro
    mostrarMensagem('registerErrorMessage', $mensagemErro, 'red');
    // Remover a variável de sessão
    unset($_SESSION['cadastro_erro']);
}

// Verificar se há uma mensagem de erro para o login na sessão
if (isset($_SESSION['login_erro'])) {
    // Construir a mensagem de erro
    $mensagemErro = "Erro de login: " . $_SESSION['login_erro'];
    // Exibir a mensagem de erro
    mostrarMensagem('loginErrorMessage', $mensagemErro, 'red');
    // Remover a variável de sessão
    unset($_SESSION['login_erro']);
}
if (isset($_GET['cep'])) {
    if (isset($_GET['cep'])) {
        $cep = $_GET['cep'];
        $cep = preg_replace('/[^0-9]/', '', $cep);
    
        if (strlen($cep) == 8) {
            $url = "https://viacep.com.br/ws/{$cep}/json/";
            $result = file_get_contents($url);
            $jsonResult = json_decode($result, true);
    
            // Verificar se o JSON contém informações essenciais
            if (isset($jsonResult['logradouro']) && isset($jsonResult['bairro']) && isset($jsonResult['localidade']) && isset($jsonResult['uf'])) {
                echo $result;
            } else {
                // Retornar um JSON vazio e adicionar uma bandeira indicando que as informações não estão completas
                echo json_encode(array("incompleto" => true));
            }
        }
}
}
    // Verificar se a página atual é a página de cadastro
    $paginaCadastro = false;
    if (basename($_SERVER['PHP_SELF']) == 'registro.php') {
        $paginaCadastro = true;
    }
?>


<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <title>SRSCJF-IF</title>
</head>

<body>
    <div class="wrapper">
        <nav class="nav">
            <div class="nav-logo">
                <p>LOGO .</p>
            </div>
            <div class="nav-menu" id="navMenu">
                <ul>
                    <li><a href="#" class="link active">Inicio</a></li>
                    <li><a href="novidades_em_breve.html" class="link">Sobre</a></li>
                    <li><a href="novidades_em_breve.html" class="link">Não definido</a></li>
                    <li><a href="suporte.html" class="link">Fale Conosco</a></li>
                </ul>
            </div>
            <div class="nav-button">
                <button class="btn white-btn" id="loginBtn" onclick="login()">Login</button>
                <button class="btn" id="registerBtn" onclick="cadastro()">Cadastre-se</button>
            </div>
            <div class="nav-menu-btn">
                <i class="bx bx-menu" onclick="menuFunction()"></i>
            </div>
        </nav>

        <!-- Form box -->
        <div class="form-box">
            <!-- login form -->
            <div class="login-container" id="login">
                <div class="top">
                    <span>Não tem uma conta? <a href="#" onclick="cadastro()">Cadastre-se</a></span>
                    <header>Login</header>
                    <div id="cadastrocerto" class="certo-message mensagem-container" style="display: none;"></div>
                    <div id="registerErrorMessage" class="error-message mensagem-container" style="display: none;"></div>
                    <div id="loginErrorMessage" class="error-message mensagem-container" style="display: none;"></div>
                    <br>
                </div>

                <form action="login.php" method="POST">
                    <div class="input-box">
                        <input type="text" class="input-field" placeholder="Matrícula" name="matricula" required>
                        <i class="bx bx-user"></i>
                    </div>
                    <div class="input-box">
                        <input type="password" class="input-field" placeholder="Senha" name="senha" required>
                        <i class="bx bx-lock-alt"></i>
                    </div>
                    <div class="input-box">
                        <input type="submit" class="submit" value="Login" name="login">
                    </div>
                    <div class="two-col">
                        <div class="one">
                            <input type="checkbox" id="login-check">
                            <label for="login-check"> Relembre-me</label>
                        </div>

                        <div class="two">
                            <label><a href="#">Esqueceu a senha?</a></label>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Formulario de cadastro -->
            <div class="register-container elemento-com-barra-de-rolagem" id="register">
                <div class="top">
                    <span>Já tem uma conta? <a href="#" onclick="login()">Login</a></span>
                    <header>Cadastre-se</header>
                    <div id="cadastrocerto" class="certo-message mensagem-container" style="display: none;"></div>
                    <div id="registerErrorMessage" class="error-message mensagem-container" style="display: none;"></div>
                    <div id="loginErrorMessage" class="error-message mensagem-container" style="display: none;"></div>
                </div>
                <form action="registro.php" method="POST">
                    <div class="two-forms">
                        <div class="input-box">
                            <input type="text" class="input-field" placeholder="Nome" name="nome" required>
                            <i class="bx bx-user"></i>
                        </div>
                        <div class="input-box">
                            <input type="text" class="input-field" placeholder="Sobrenome" name="sobrenome" required>
                            <i class="bx bx-user"></i>
                        </div>
                    </div>
                    <div class="input-box">
                        <input type="text" class="input-field" placeholder="Matrícula" name="matricula" pattern="[0-9]{12}" title="Digite uma matrícula com 12 dígitos" required>
                        <i class="bx bx-envelope"></i>
                    </div>
                    <div class="input-box">
                        <input type="text" class="input-field" placeholder="Telefone" name="telefone" data-mask="(00) 00000-0000" required>
                        <i class="bx bx-phone"></i>
                    </div>
                    <div class="input-box">
                        <input id="cep" type="text" class="input-field" placeholder="CEP" name="cep" id="cep" data-mask="00000-000">
                        <i class="bx bx-location-plus"></i>
                    </div>
                    <div class="input-box">
                        <input type="text" class="input-field" placeholder="Rua" name="rua" id="rua" required>
                        <i class="bx bx-home-alt"></i>
                    </div>
                    <div class="input-box">
                        <input type="text" class="input-field" placeholder="Bairro" name="bairro" id="bairro" required>
                        <i class="bx bx-home"></i>
                    </div>
                    <div class="input-box">
                        <input type="text" class="input-field" placeholder="Cidade" name="cidade" id="cidade" required>
                        <i class="bx bx-building-house"></i>
                    </div>
                    <div class="input-box">
                        <input type="text" class="input-field" placeholder="Estado" name="estado" id="estado" required>
                        <i class="bx bx-flag"></i>
                    </div>
                    <div class="input-box">
                        <input type="text" class="input-field" placeholder="Número da Casa" name="numerocasa" id="numerocasa" required>
                        <i class="bx bx-home"></i> <!-- Ícone de casa -->
                    </div>
                    <div class="input-box">
                        <select id="curso" class="input-field" name="curso" required>
                            <option value="" disabled selected hidden>Escolha o curso</option>
                            <?php
                            include "config.php"; // Certifique-se de que o arquivo de configuração esteja incluído e configure a conexão com o banco de dados.

                            // Preencha o menu suspenso com as opções do banco de dados
                            $sql = "SELECT `nome_do_curso`, `id_curso` FROM `cursos`";
                            $result = $mysqli->query($sql);

                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo '<option value="' . $row['id_curso'] . '">' . $row['nome_do_curso'] . '</option>';
                                }
                            }
                            ?>
                        </select>
                        <i class="bx bxs-school"></i>
                    </div>
                    <div class="input-box">
                        <input type="password" class="input-field" placeholder="Senha" name="senha" required>
                        <i class="bx bx-lock-alt"></i>
                    </div>
                    <div class="input-box">
                        <input type="password" class="input-field" placeholder="Confirmar Senha" name="confirmar_senha" required>
                        <i class="bx bx-lock-alt"></i>
                    </div>
                    <div class="input-box">
                        <input type="submit" class="submit" value="Cadastre-se" name="cadastrar">
                    </div>
                    <div class="two-col">
                        <div class="one">
                            <input type="checkbox" id="register-check">
                            <label for="register-check"> Relembre-me</label>
                        </div>
                        <div class="two">
                            <label><a href="#">Termos & condições</a></label>
                        </div>
                    </div>
                </form>
            </div>
            <!-- Seta de rolagem -->
            <div class="scroll-container">
                <div class="scroll-arrow hidden" id="scrollArrow">
                    <a href="#numerocasa"><i class="fas fa-chevron-up"></i></a>
                </div>
            </div>
        </div>
    </div>


    </div>
    </script>
    <script>
    (function() {
        const cep = document.querySelector("input[name=cep]");

        cep.addEventListener('blur', function(e) {
            const value = cep.value.replace(/[^0-9]+/, '');
            const url = `https://viacep.com.br/ws/${value}/json/`;

            fetch(url)
                .then(response => response.json())
                .then(json => {
                    if (json.logradouro) {
                        document.querySelector('input[name=rua]').value = json.logradouro;
                    } else {
                        document.querySelector('input[name=rua]').value = '';
                    }

                    if (json.bairro) {
                        document.querySelector('input[name=bairro]').value = json.bairro;
                    } else {
                        document.querySelector('input[name=bairro]').value = '';
                    }

                    if (json.localidade) {
                        document.querySelector('input[name=cidade]').value = json.localidade;
                    } else {
                        document.querySelector('input[name=cidade]').value = '';
                    }

                    if (json.uf) {
                        document.querySelector('input[name=estado]').value = json.uf;
                    } else {
                        document.querySelector('input[name=estado]').value = '';
                    }

                    // Verificar se o JSON está incompleto e mostrar uma mensagem
                    if (json.incompleto) {
                        mostrarMensagem('cadastrocerto', 'As informações do CEP estão incompletas. Preencha manualmente os campos faltantes.', 'orange');
                    }
                });
        });
    })();

        ///site usado para aprendizado https://www.mxcursos.com/blog/como-consultar-cep-utilizando-javascript/
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="script.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>


</body>

</html>