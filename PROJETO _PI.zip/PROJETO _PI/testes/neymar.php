<?php
// Iniciar a sessão
session_start();

// Definir variáveis de sessão
$_SESSION['usuario'] = 'João';
$_SESSION['logado'] = true;

// Acessar as variáveis de sessão
$usuario = $_SESSION['usuario'];
$logado = $_SESSION['logado'];

// Imprimir os valores das variáveis de sessão
echo 'Usuário: ' . $usuario . '<br>';
echo 'Logado: ' . ($logado ? 'Sim' : 'Não') . '<br>';

// Encerrar a sessão
session_unset();
session_destroy();
?>
