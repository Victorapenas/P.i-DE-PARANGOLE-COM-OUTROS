<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Indicação de Rolagem</title>
  <link rel="stylesheet" href="styles.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }

    .section {
      height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      background-color: #f0f0f0;
    }

    .scroll-indicator {
      text-align: center;
      padding: 20px;
      cursor: pointer;
    }

    .scroll-indicator i {
      font-size: 24px;
    }

    .section-with-gradient {
      background: linear-gradient(transparent, rgba(0, 0, 0, 0.3)), url('background.jpg');
      background-size: cover;
      background-position: center;
      color: #fff;
    }

    .scroll-arrow {
      transition: transform 0.3s ease;
    }

    .scroll-arrow.rotated {
      transform: rotate(180deg);
    }

    .pulse-indicator {
      animation: pulse 1.5s infinite;
    }

    @keyframes pulse {
      0% {
        transform: scale(1);
      }
      50% {
        transform: scale(1.2);
      }
      100% {
        transform: scale(1);
      }
    }
  </style>
</head>
<body>
  <div class="section">
    <h1>Seção 1</h1>
    <p>Conteúdo da seção 1</p>
    <div class="scroll-indicator">
      <span>Role para baixo</span>
      <i class="fas fa-chevron-down scroll-arrow"></i>
    </div>
  </div>

  <div class="section section-with-gradient">
    <h1>Seção 2</h1>
    <p>Conteúdo da seção 2</p>
    <div class="scroll-indicator pulse-indicator">
      <span>Role para ver mais</span>
      <i class="fas fa-chevron-down scroll-arrow rotated"></i>
    </div>
  </div>

  <script>
    // JavaScript para adicionar/remover classe "rotated" quando o usuário rola a página
    window.addEventListener('scroll', () => {
      const scrollIndicator = document.querySelector('.scroll-arrow');
      const section2 = document.querySelector('.section-with-gradient');
      const section2Top = section2.getBoundingClientRect().top;

      if (section2Top < window.innerHeight / 2) {
        scrollIndicator.classList.add('rotated');
      } else {
        scrollIndicator.classList.remove('rotated');
      }
    });
  </script>
</body>
</html>
