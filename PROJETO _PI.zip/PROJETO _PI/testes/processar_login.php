<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Login</title>
    <link rel="stylesheet" href="style.css">
    <script>
        function displayError(message) {
            document.getElementById('errorMessage').innerText = message;
        }
    </script>
</head>
<style>
    /* style.css */
.login-container {
    width: 300px;
    margin: auto;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
    text-align: center;
    background-color: #f9f9f9;
}

.login-container h2 {
    margin-bottom: 20px;
    color: #333;
}

.input-box {
    margin-bottom: 15px;
}

.input-box input {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.error-message {
    margin-top: 10px;
    color: #d9534f;
}

button {
    padding: 10px 20px;
    background-color: #337ab7;
    border: none;
    border-radius: 5px;
    color: #fff;
    cursor: pointer;
    transition: background-color 0.3s;
}

button:hover {
    background-color: #286090;
}

</style>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <form action="processar_login.php" method="POST">
            <div class="input-box">
                <input type="text" name="matricula" placeholder="Matrícula" required value="123">
            </div>
            <div class="input-box">
                <input type="password" name="senha" placeholder="Senha" required value="321">
            </div>
            <div class="error-message" id="errorMessage"></div>
            <button type="submit">Entrar</button>
        </form>
    </div>
</body>
</html>

